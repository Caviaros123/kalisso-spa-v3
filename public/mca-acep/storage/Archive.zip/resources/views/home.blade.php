@extends('layouts.master')
@section('title', 'Accueil')
@section('content')

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->


@endsection
@section('footer')
@include('layouts.footer')
@stop
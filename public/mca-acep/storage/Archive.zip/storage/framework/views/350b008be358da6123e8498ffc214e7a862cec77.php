


<?php $__env->startSection('footer'); ?>
<footer class="main-footer">
  <strong>Copyright &copy; 2021 <a href="http://mca.bank">mca.bank</a>.</strong>
  All rights reserved. by <a href="htpps://www.kalisso.com">Kalisso.com</a>
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 1.0.0
  </div>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u193595801/domains/kalisso.com/public_html/mca-acep/storage/resources/views/layouts/footer.blade.php ENDPATH**/ ?>
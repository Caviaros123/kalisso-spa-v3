<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="UTF-8">
  <meta name="description" content="<?php echo e(setting('site.description')); ?>">
  <meta name="keywords" content="auto, immo, location, maison, voiture">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <!-- Favicon -->
  <link rel="shortcut icon" href="<?php echo e(asset('storage/'.setting('site.logo'))); ?>" type="image/png">

  <title><?php echo e(setting('site.title')); ?> | <?php echo $__env->yieldContent('title'); ?> </title>
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('assets/dist/css/adminlte.min.css')); ?>">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  <?php echo $__env->yieldContent('css'); ?>
  <?php echo $__env->yieldContent('withdrawl_css'); ?>
  <?php echo $__env->yieldContent('decouvert_css'); ?>
  <?php echo $__env->yieldContent('deposit_css'); ?>
  <?php echo $__env->yieldContent('transfert_css'); ?>
  <style type="text/css">
      .select2-container .select2-selection--single .select2-selection__rendered{
          padding-right: 7rem!important;
      }
  </style>
  <link href="<?php echo e(asset('src/select2.min.css')); ?>" rel="stylesheet" />
  <script src="<?php echo e(asset('src/select2.min.js')); ?>" defer></script>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div id="app">

    <div class="wrapper">
      <!-- Navbar -->
      <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
          </li>

        </ul>
      </nav>
      <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('pages.modal_global.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <!-- /.content-wrapper -->

      <?php echo $__env->yieldContent('footer'); ?>
    </div>
  </div>

  <!-- Js Plugins -->
  
    
 <script src="<?php echo e(asset('js/app.js')); ?>" ></script> 
  <?php echo $__env->yieldContent('js'); ?>
  <?php echo $__env->yieldContent('withdrawl_js'); ?>
  <?php echo $__env->yieldContent('decouvert_js'); ?>
  <?php echo $__env->yieldContent('deposit_js'); ?>
  <?php echo $__env->yieldContent('transfert_js'); ?>
  <script type="text/javascript">
      $(document).ready(function(){
        $('.notfound').hide();
        // Search all columns
        $('#txt_searchall').keyup(function(){
          // Search Text
          var search = $(this).val();

          // Hide all table tbody rows
          $('table tbody tr').hide();

          // Count total search result
          var len = $('table tbody tr:not(.notfound) td:contains("'+search+'")').length;

          if(len > 0){
            // Searching text in columns and show match row
            $('table tbody tr:not(.notfound) td:contains("'+search+'")').each(function(){
              $(this).closest('tr').show();
            });

          }else{
            // $('.notfound').removeAttribute("hidden");
            $('.notfound').show();
          }

        });

        // Search on name column only
        $('#txt_name').keyup(function(){
          // Search Text
          var search = $(this).val();

          // Hide all table tbody rows
          $('table tbody tr').hide();

          // Count total search result
          var len = $('table tbody tr:not(.notfound) td:nth-child(2):contains("'+search+'")').length;

          if(len > 0){
            // Searching text in columns and show match row
            $('table tbody tr:not(.notfound) td:contains("'+search+'")').each(function(){
               $(this).closest('tr').show();
            });
          }else{
            $('.notfound').show();
          }

        });

      });

    // Case-insensitive searching (Note - remove the below script for Case sensitive search )
    $.expr[":"].contains = $.expr.createPseudo(function(arg) {
       return function( elem ) {
         return $(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
       };
    });

    $(document).ready(function() {
        $('.js-example-basic-single').select2({
           placeholder:  'Selectionner un membre',
           allowClear: true
        });
    });

    
</script>

  <!-- AdminLTE App -->

  <script src="<?php echo e(asset('assets/dist/js/adminlte.js')); ?>"></script>  
    
</body>

</html><?php /**PATH /home/u193595801/domains/kalisso.com/public_html/mca-acep/storage/resources/views/layouts/master.blade.php ENDPATH**/ ?>